export default function Blog() {
  return (
    <section className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Blog</h2>
      <p className="text-gray-700 leading-relaxed">Escreva seus artigos e insights.</p>
    </section>
  );
}