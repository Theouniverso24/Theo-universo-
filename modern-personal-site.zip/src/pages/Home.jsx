export default function Home() {
  return (
    <section className="flex flex-col items-center justify-center h-[80vh] text-center px-4">
      <h2 className="text-4xl font-bold mb-4">Olá, sou [Seu Nome]</h2>
      <p className="text-lg text-gray-600 mb-6">Desenvolvedor Web | Criador de experiências digitais</p>
    </section>
  );
}