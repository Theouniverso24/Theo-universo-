export default function Portfolio() {
  return (
    <section className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Portfólio</h2>
      <p className="text-gray-700 leading-relaxed">Mostre seus projetos aqui.</p>
    </section>
  );
}