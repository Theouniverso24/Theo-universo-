export default function About() {
  return (
    <section className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Sobre Mim</h2>
      <p className="text-gray-700 leading-relaxed">
        Aqui você pode escrever sobre sua experiência, habilidades e interesses.
      </p>
    </section>
  );
}