import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
      <h1 className="text-2xl font-bold">Seu Nome</h1>
      <ul className="flex space-x-4">
        <li><Link to="/">Início</Link></li>
        <li><Link to="/about">Sobre</Link></li>
        <li><Link to="/portfolio">Portfólio</Link></li>
        <li><Link to="/blog">Blog</Link></li>
        <li><Link to="/contact">Contato</Link></li>
      </ul>
    </nav>
  );
}